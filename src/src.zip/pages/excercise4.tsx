import Hook1 from "../components/ex4/hook1"
import Hook3 from "../components/ex4/hook3"
import Hook2 from "../components/ex4/hook2"


const HookExcercise = () => {


  return (<>
    <Hook1 />
    <Hook2 />
    <Hook3 />
  </>)
}

export default HookExcercise